# ==============================================================================
# 🌐 FILE CẤU HÌNH MÁY CHỦ WSGI (myproject/wsgi.py)
# Dùng để triển khai website lên máy chủ thực tế (Production Server như Nginx, Gunicorn)
# ==============================================================================
import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'du_an.settings')

application = get_wsgi_application()
