# ==============================================================================
# ⚡ FILE CẤU HÌNH GIAO THỨC BẤT ĐỒNG BỘ ASGI (myproject/asgi.py)
# Dùng khi dự án phát triển các tính năng thời gian thực như WebSocket, Chatbox
# ==============================================================================
import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'du_an.settings')

application = get_asgi_application()
