import os
import sys
import django

# Bổ sung đường dẫn thư mục gốc để Python tìm thấy 'myproject' và 'shops'
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.append(BASE_DIR)

# Khởi tạo cấu hình Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'du_an.settings')
django.setup()

# Import model
from cua_hang.models import Category, Product

def seed_data():
    print("Đang xóa dữ liệu cũ...")
    Product.objects.all().delete()
    Category.objects.all().delete()

    print("Đang tạo danh mục One Piece...")
    cat_strawhat = Category.objects.create(name="Băng Mũ Rơm", slug="bang-mu-rom")
    cat_yonko = Category.objects.create(name="Tứ Hoàng", slug="tu-hoang")
    cat_navy = Category.objects.create(name="Hải Quân", slug="hai-quan")

    print("Đang tạo danh sách mô hình...")
    products = [
        {
            "category": cat_strawhat,
            "name": "Mô hình Luffy Gear 5 Nika",
            "slug": "luffy-gear-5-nika",
            "price": 1500000,
            "height": "28 cm",
            "material": "PVC / ABS Cao cấp",
            "image": "https://images2.alphacoders.com/131/1312386.jpeg",
            "description": "Mô hình Monkey D. Luffy trạng thái Thần Mặt Trời Nika Gear 5 cực ngầu, hiệu ứng mây bay sắc nét."
        },
        {
            "category": cat_strawhat,
            "name": "Mô hình Roronoa Zoro Cửu Kiếm Phái",
            "slug": "zoro-cuu-kiem-phai",
            "price": 1250000,
            "height": "25 cm",
            "material": "PVC Cao cấp",
            "image": "https://images4.alphacoders.com/132/1325338.jpeg",
            "description": "Mô hình Roronoa Zoro thi triển chiêu thức Ashura 9 kiếm với hiệu ứng quỷ khí tím siêu đẹp."
        },
        {
            "category": cat_yonko,
            "name": "Mô hình Shanks Tóc Đỏ Haki Bá Vương",
            "slug": "shanks-toc-do-haki",
            "price": 1800000,
            "height": "30 cm",
            "material": "Resin / PVC",
            "image": "https://images5.alphacoders.com/132/1328405.jpeg",
            "description": "Mô hình Tứ Hoàng Shanks Tóc Đỏ tuốt kiếm Gryphon tỏa Haki màu đỏ đen uy lực."
        },
        {
            "category": cat_navy,
            "name": "Mô hình Đô Đốc Akainu Thần Chó Lửa",
            "slug": "akainu-dung-nham",
            "price": 1400000,
            "height": "27 cm",
            "material": "PVC Cao cấp",
            "image": "https://images3.alphacoders.com/132/1328407.jpeg",
            "description": "Mô hình Đô đốc Thủy sư Akainu Sakazuki biến thành Dung Nham cực sống động."
        }
    ]

    for item in products:
        Product.objects.create(**item)

    print("✅ ĐÃ THÊM DỮ LIỆU THÀNH CÔNG!")

if __name__ == "__main__":
    seed_data()