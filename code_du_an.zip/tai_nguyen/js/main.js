// ==============================================================================
// ⚡ JAVASCRIPT XỬ LÝ SỰ KIỆN GIAO DIỆN (static/js/main.js)
// - Tự động tắt thông báo alert sau 4 giây
// - Nút tăng giảm số lượng sản phẩm ở trang chi tiết mô hình
// - Nút bấm sao chép số tài khoản ngân hàng khi thanh toán
// ==============================================================================

document.addEventListener('DOMContentLoaded', function() {
    // Auto-dismiss alerts after 4 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 4000);

    // Quantity buttons on product detail
    const qtyInput = document.getElementById('product-quantity');
    const btnMinus = document.getElementById('btn-minus');
    const btnPlus = document.getElementById('btn-plus');

    if (qtyInput && btnMinus && btnPlus) {
        btnMinus.addEventListener('click', function() {
            let val = parseInt(qtyInput.value) || 1;
            if (val > 1) qtyInput.value = val - 1;
        });
        btnPlus.addEventListener('click', function() {
            let val = parseInt(qtyInput.value) || 1;
            qtyInput.value = val + 1;
        });
    }

    // Copy bank account info
    const copyBtns = document.querySelectorAll('.btn-copy');
    copyBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const textToCopy = this.getAttribute('data-copy');
            navigator.clipboard.writeText(textToCopy).then(() => {
                const originalHtml = this.innerHTML;
                this.innerHTML = '<i class="fa-solid fa-check"></i> Đã sao chép';
                setTimeout(() => {
                    this.innerHTML = originalHtml;
                }, 2000);
            });
        });
    });
});
